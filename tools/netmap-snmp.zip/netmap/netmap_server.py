# -*- coding: utf-8 -*-
"""
netmap 監控服務：在內網提供「機房線路對應圖」網頁，並定時用 SNMP 讀取每個埠的流量與上下線狀態。

  網頁        http://<這台電腦>:8080/
  API         GET  /api/project          目前的圖（含 rev）
              PUT  /api/project          儲存（rev 不符回 409）
              GET  /api/status           即時狀態：設備可達、每個埠 up/down、流量、使用率、錯誤
              GET  /api/history?port=..  埠的歷史流量（預設 24 小時）
              GET  /api/mrtg?port=..     MRTG 式流量圖資料（日／週／月／年）
              GET  /api/mrtg/summary     所有埠最近 24 小時的流量摘要
              GET  /api/mrtg/device?id=..&view=day|week|month|year  一台設備所有埠的流量圖
              GET  /api/flow/status | /api/flow/top?min=60 | /api/flow/host?ip=..&min=60   流量明細（NetFlow／IPFIX／sFlow）
              GET  /api/events  /api/pinghist?id=..  /api/seen  /api/revs  /api/revs/get?rev=..   事件、心跳、網路上的設備、歷史版本
              POST /api/revs/restore  /api/login  /api/logout  /api/alerts/test  /api/seen/forget
              GET|PUT /api/settings   告警、心跳、權限（管理員）
  修改用的請求（POST／PUT）都要帶 X-Netmap: 1 標頭。
"""
import base64, hashlib, hmac, http.server, json, os, re, secrets, socket, sqlite3, sys, threading, time, urllib.parse, zlib
from concurrent.futures import ThreadPoolExecutor

import netmap_snmp as ns
import netmap_sshmon as sm
import netmap_flow as nf
import netmap_alert as na

APP = "netmap"
# 主控台不是 UTF-8 時（英文版 Windows、輸出導到檔案）也不要因為中文訊息當掉
for _st in (sys.stdout, sys.stderr):
    try: _st.reconfigure(errors="replace")
    except Exception: pass

VERSION = "1.9.1"

# ───────────────────────── paths & secrets ─────────────────────────
def data_dir():
    base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), ".config")
    d = os.path.join(base, APP)
    os.makedirs(d, exist_ok=True)
    return d

def web_index():
    cands = []
    if getattr(sys, "_MEIPASS", None): cands.append(os.path.join(sys._MEIPASS, "web", "index.html"))
    here = os.path.dirname(os.path.abspath(__file__))
    cands += [os.path.join(here, "web", "index.html"), os.path.join(here, "..", "..", "index.html")]
    for c in cands:
        if os.path.exists(c): return c
    return None

def _dpapi(data, protect):
    import ctypes
    from ctypes import wintypes
    class BLOB(ctypes.Structure): _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
    buf = ctypes.create_string_buffer(data, len(data))
    inp = BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))); out = BLOB()
    fn = ctypes.windll.crypt32.CryptProtectData if protect else ctypes.windll.crypt32.CryptUnprotectData
    ok = fn(ctypes.byref(inp), None, None, None, None, 0, ctypes.byref(out)) if protect else fn(ctypes.byref(inp), None, None, None, None, 0, ctypes.byref(out))
    if not ok: raise OSError("DPAPI failed")
    res = ctypes.string_at(out.pbData, out.cbData); ctypes.windll.kernel32.LocalFree(out.pbData); return res

def protect(text):
    """Windows：用 DPAPI 加密（只有同一個 Windows 帳號能解開）；其他系統只做編碼。"""
    if not text: return ""
    raw = text.encode("utf-8")
    if os.name == "nt":
        try: return "dpapi:" + base64.b64encode(_dpapi(raw, True)).decode()
        except Exception: pass
    return "b64:" + base64.b64encode(raw).decode()

def unprotect(val):
    if not val: return ""
    try:
        if val.startswith("dpapi:"): return _dpapi(base64.b64decode(val[6:]), False).decode("utf-8")
        if val.startswith("b64:"): return base64.b64decode(val[4:]).decode("utf-8")
    except Exception: return ""
    return val

def local_ips():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(("10.255.255.255", 1)); ips.add(s.getsockname()[0]); s.close()
    except Exception: pass
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            if not ip.startswith("127."): ips.add(ip)
    except Exception: pass
    return sorted(ips) or ["127.0.0.1"]

def local_nics():
    """這台電腦的網卡：{名稱: {"ips": [...], "rx": 收到位元組, "tx": 送出位元組, "ie", "oe", "up", "speed"(bps)}}。需要 psutil（netmap.exe 已內含）。"""
    try:
        import psutil
    except ImportError:
        return None
    addrs, io, st = psutil.net_if_addrs(), psutil.net_io_counters(pernic=True), psutil.net_if_stats()
    out = {}
    for name, c in io.items():
        ips = [a.address.split("%")[0] for a in addrs.get(name, []) if a.family in (socket.AF_INET, socket.AF_INET6)]
        x = st.get(name)
        out[name] = {"ips": ips, "rx": c.bytes_recv, "tx": c.bytes_sent, "ie": c.errin, "oe": c.errout,
                     "up": bool(x.isup) if x else None, "speed": (x.speed or 0) * 1_000_000 if x else 0}
    return out


_self_cache = [0.0, set()]
def self_ips():
    """這台電腦所有的 IP（給「自動監控自己」比對用），快取 60 秒。"""
    if time.time() - _self_cache[0] > 60:
        nics = local_nics()
        ips = {ip for n in (nics or {}).values() for ip in n["ips"]} | set(local_ips())
        _self_cache[0], _self_cache[1] = time.time(), {ip for ip in ips if not ip.startswith("127.") and ip != "::1"}
    return _self_cache[1]


# ───────────────────────── store ─────────────────────────
# MRTG 的四種解析度：(每點秒數, 保存秒數) 與 (圖名, 圖上顯示的時間範圍)
ROLLUPS = [(300, 3 * 86400), (1800, 14 * 86400), (7200, 62 * 86400), (86400, 800 * 86400)]
MRTG_VIEWS = [("day", 33 * 3600), ("week", 8 * 86400), ("month", 35 * 86400), ("year", 400 * 86400)]

# 線上版網頁偵測本機 netmap.exe：只有使用者勾選才開，只回答 /api/ping，只給這台電腦自己的瀏覽器
DETECT_ORIGINS = {"https://coloplay1.github.io"}

DEFAULT_SETTINGS = {"port": 8080, "interval": 60, "retention_days": 7, "lan_edit": False, "autostart": False, "autorun": True, "web_detect": False, "monitor_self": True,
                    "flow_enabled": False, "flow_port": 2055, "sflow_port": 6343,
                    "ping_enabled": True, "ping_interval": 30, "ping_fails": 2, "ping_slow_ms": 200, "ping_timeout": 1.0,
                    "alerts": {"enabled": False, "site": "", "on": {"down": True, "recover": True, "port": True, "slow": False, "snmp": False, "newdev": False, "gone": False}, "channels": []},
                    "admin_hash": "", "view_token": "", "view_required": False, "inv_enabled": True, "inv_gone_hours": 24, "snmp_autoprobe": True,
                    "snmp": {"version": "2c", "community": "", "user": "", "auth_proto": "SHA", "auth_key": "", "priv_proto": "AES", "priv_key": "",
                             "context": "", "port": 161, "timeout": 2.0, "retries": 1}}

PROJECT_KEYS = ("devices", "cables", "racks", "faults", "pages", "trunks")

def norm_mac(m):
    h = re.sub(r"[^0-9a-fA-F]", "", str(m or "")).lower()
    return ":".join(h[i:i + 2] for i in range(0, 12, 2)) if len(h) == 12 and h not in ("000000000000", "ffffffffffff") else ""

def diff_projects(a, b):
    """兩個版本的差異摘要：{"text": "...", "devices": {"add": [...], "del": [...], "mod": [...]}, "cables": {...}, "moved": n}"""
    da = {d["id"]: d for d in a.get("devices", []) if isinstance(d, dict) and d.get("id")}
    db = {d["id"]: d for d in b.get("devices", []) if isinstance(d, dict) and d.get("id")}
    ca = {c["id"]: c for c in a.get("cables", []) if isinstance(c, dict) and c.get("id")}
    cb = {c["id"]: c for c in b.get("cables", []) if isinstance(c, dict) and c.get("id")}
    pname = {}
    for dd in (da, db):
        for d in dd.values():
            for p in d.get("ports", []): pname[p.get("id")] = f"{d.get('name', '')} {p.get('label', '')}".strip()
    cname = lambda c: (c.get("label") or "") + f"（{pname.get(c.get('a'), '?')} ↔ {pname.get(c.get('b'), '?')}）"
    strip = lambda d, keys: {k: v for k, v in d.items() if k not in keys}
    add = [db[k].get("name", "") for k in db if k not in da]; rem = [da[k].get("name", "") for k in da if k not in db]
    mod, moved = [], 0
    for k in db:
        if k in da and da[k] != db[k]:
            if strip(da[k], ("x", "y")) == strip(db[k], ("x", "y")): moved += 1
            else: mod.append(db[k].get("name", ""))
    cadd = [cname(cb[k]) for k in cb if k not in ca]; crem = [cname(ca[k]) for k in ca if k not in cb]
    cmod, cmoved = [], 0
    for k in cb:
        if k in ca and ca[k] != cb[k]:
            if strip(ca[k], ("wps",)) == strip(cb[k], ("wps",)): cmoved += 1
            else: cmod.append(cname(cb[k]))
    other = [k for k in ("racks", "faults", "pages", "trunks") if (a.get(k) or []) != (b.get(k) or [])]
    parts = []
    def P(n, verb, what, names):
        if n: parts.append(f"{verb}{what} {n}" + (f"（{'、'.join(x for x in names[:3] if x)}{'…' if n > 3 else ''}）" if any(names[:3]) else ""))
    P(len(add), "新增", "設備", add); P(len(rem), "刪除", "設備", rem); P(len(mod), "修改", "設備", mod)
    P(len(cadd), "接上", "線", [c.split("（")[0] or c for c in cadd]); P(len(crem), "拔掉", "線", [c.split("（")[0] or c for c in crem]); P(len(cmod), "修改", "線", [c.split("（")[0] for c in cmod])
    if moved or cmoved: parts.append("調整版面")
    names = {"racks": "機櫃", "faults": "故障紀錄", "pages": "頁面", "trunks": "光纖束"}
    if other: parts.append("修改" + "、".join(names[k] for k in other))
    return {"text": "、".join(parts) or "沒有變更", "devices": {"add": add, "del": rem, "mod": mod}, "cables": {"add": cadd, "del": crem, "mod": cmod}, "moved": moved + cmoved, "other": other}


class Store:
    def __init__(s, root=None):
        s.dir = root or data_dir(); os.makedirs(s.dir, exist_ok=True)
        s.lock = threading.RLock()
        s.settings = json.loads(json.dumps(DEFAULT_SETTINGS))
        p = os.path.join(s.dir, "settings.json")
        if os.path.exists(p):
            try:
                saved = json.load(open(p, encoding="utf-8"))
                snmp = {**s.settings["snmp"], **saved.get("snmp", {})}
                s.settings.update(saved); s.settings["snmp"] = snmp
            except Exception: pass
        if not s.settings["snmp"].get("community"): s.settings["snmp"]["community"] = protect("public")
        s.rev, s.project = 0, {"devices": [], "cables": [], "racks": [], "faults": []}
        pp = os.path.join(s.dir, "project.json")
        if os.path.exists(pp):
            try:
                o = json.load(open(pp, encoding="utf-8")); s.rev = int(o.get("rev", 1)); s.project = o.get("project") or s.project
            except Exception: pass
        s.db = sqlite3.connect(os.path.join(s.dir, "metrics.db"), check_same_thread=False)
        s.db.execute("PRAGMA journal_mode=WAL")
        s.db.execute("CREATE TABLE IF NOT EXISTS samples(ts INTEGER, pid TEXT, inb REAL, outb REAL, up INTEGER, ierr INTEGER, oerr INTEGER)")
        s.db.execute("CREATE INDEX IF NOT EXISTS ix_samples ON samples(pid, ts)")
        # MRTG 式彙整：每個埠在 5 分鐘／30 分鐘／2 小時／1 天的平均與最大值，保存期比原始紀錄長
        s.db.execute("CREATE TABLE IF NOT EXISTS rollup(pid TEXT, res INTEGER, ts INTEGER, n INTEGER, sin REAL, sout REAL, xin REAL, xout REAL, upn INTEGER, spd REAL, PRIMARY KEY(pid, res, ts))")
        # 事件（斷線／恢復／新設備…）、圖的歷史版本、網路上看過的設備
        s.db.execute("CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, kind TEXT, level TEXT, dev TEXT, port TEXT, text TEXT, data TEXT)")
        s.db.execute("CREATE INDEX IF NOT EXISTS ix_events ON events(ts)")
        s.db.execute("CREATE TABLE IF NOT EXISTS revs(rev INTEGER PRIMARY KEY, ts INTEGER, who TEXT, summary TEXT, detail TEXT, data BLOB)")
        s.db.execute("CREATE TABLE IF NOT EXISTS seen(mac TEXT PRIMARY KEY, ip TEXT, name TEXT, vendor TEXT, first INTEGER, last INTEGER, src TEXT, via TEXT, wireless INTEGER, gone INTEGER DEFAULT 0, ips TEXT)")
        s.db.commit()
        if not s.db.execute("SELECT 1 FROM revs LIMIT 1").fetchone() and s.project.get("devices"):
            s._add_rev(s.rev, s.project, None, "升級前的版本", int(time.time())); s.db.commit()
        if not s.db.execute("SELECT 1 FROM rollup LIMIT 1").fetchone() and s.db.execute("SELECT 1 FROM samples LIMIT 1").fetchone():
            for res, _ in ROLLUPS:   # 舊版升級：用現有的原始紀錄補出彙整
                s.db.execute("INSERT OR REPLACE INTO rollup SELECT pid, ?, (ts/?)*?, COUNT(*), SUM(COALESCE(inb,0)), SUM(COALESCE(outb,0)), MAX(COALESCE(inb,0)), MAX(COALESCE(outb,0)), SUM(up), 0 "
                             "FROM samples WHERE inb IS NOT NULL GROUP BY pid, (ts/?)", (res, res, res, res))
            s.db.commit()

    # ---------- SSH 監控的帳密（只存在這台電腦，不會送到網頁） ----------
    def ssh_creds(s, host):
        c = (s.settings.get("ssh") or {}).get(host)
        if not c: return None
        return {"user": c.get("user", ""), "password": unprotect(c.get("pw")), "hostkey": c.get("hostkey", "")}

    def add_ssh_device(s, info, user, password):
        """把 SSH 監控設備加到圖上（同 IP 的設備就沿用並補上介面）。回傳 (設備, 是否新建)。"""
        ip, port = info["host"], int(info.get("port") or 22); key = f"{ip}:{port}"
        s.settings.setdefault("ssh", {})[key] = {"user": user, "pw": protect(password), "hostkey": info.get("hostkey", "")}
        s.save_settings()
        with s.lock:
            proj = json.loads(json.dumps(s.project)); devs = proj.setdefault("devices", [])
        d = next((x for x in devs if x.get("ip") == ip or (x.get("sshmon") or {}).get("host") == key), None)
        created = d is None
        if created:
            typ = info.get("type") or "router"
            d = {"id": ns.nid("d"), "type": "end" if typ == "server" else typ, "name": info.get("name") or ip, "brand": info.get("brand", ""),
                 "model": info.get("model", ""), "ip": ip, "mac": "", "gw": "", "loc": "", "rack": "", "u": "", "uh": "", "x": 0, "y": 0, "ports": []}
            if typ == "server": d["kind"] = "伺服器"
            devs.append(d)
        d["sshmon"] = {"host": key}; d.pop("monitor", None)
        d["note"] = " ".join(x for x in [f"SSH 監控 {time.strftime('%Y-%m-%d')}", info.get("firmware", ""), info.get("kernel", "")] if x)
        if info.get("brand") and not d.get("brand"): d["brand"] = info["brand"]
        if info.get("model") and not d.get("model"): d["model"] = info["model"]
        bylab = {str(p.get("label", "")).lower(): p for p in d.get("ports", [])}
        for ifn, lab, note in info.get("ports", []):
            p = bylab.get(lab.lower()) or next((q for q in d["ports"] if q.get("ifName") == ifn), None)
            if not p:
                p = {"id": ns.nid("p"), "label": lab, "kind": "rj45", "poe": False, "mode": "access", "vlan": "", "tagged": "", "lag": "", "note": note}
                d["ports"].append(p)
            p["ifName"] = ifn
        others = [x for x in devs if x is not d and (x.get("x") or x.get("y"))]
        if created and others:   # 放在現有圖的右邊，不打亂原本的版面
            d["x"] = max(x.get("x") or 0 for x in others) + 300; d["y"] = min(x.get("y") or 0 for x in others)
        s.set_project(proj)
        return d, created

    def remove_ssh(s, dev_id):
        """停止這台設備的 SSH 監控並刪掉帳密（設備留在圖上）。"""
        with s.lock:
            proj = json.loads(json.dumps(s.project))
        d = next((x for x in proj.get("devices", []) if x["id"] == dev_id), None)
        if not d or not d.get("sshmon"): return False
        key = d.pop("sshmon")["host"]; d["monitor"] = False
        (s.settings.get("ssh") or {}).pop(key, None); s.save_settings()
        s.set_project(proj)
        return True

    def save_settings(s):
        with s.lock:
            tmp = os.path.join(s.dir, "settings.json.tmp")
            json.dump(s.settings, open(tmp, "w", encoding="utf-8"), ensure_ascii=False, indent=1); os.replace(tmp, os.path.join(s.dir, "settings.json"))

    def snmp_opts(s):
        c = s.settings["snmp"]
        return ns.opts(version=c.get("version", "2c"), community=unprotect(c.get("community")) or "public", user=c.get("user") or None,
                       auth_proto=c.get("auth_proto") or "SHA", auth_key=unprotect(c.get("auth_key")) or None, priv_proto=c.get("priv_proto") or "AES",
                       priv_key=unprotect(c.get("priv_key")) or None, context=c.get("context") or "", port=int(c.get("port") or 161),
                       timeout=float(c.get("timeout") or 2), retries=int(c.get("retries") if c.get("retries") is not None else 1))

    def set_project(s, project, base_rev=None, who="", note=None):
        with s.lock:
            if base_rev is not None and int(base_rev) != s.rev: return False
            project = {k: project.get(k, []) for k in PROJECT_KEYS}
            before = s.project
            s.project = project; s.rev += 1
            tmp = os.path.join(s.dir, "project.json.tmp")
            json.dump({"rev": s.rev, "savedAt": time.strftime("%Y-%m-%dT%H:%M:%S"), "project": project}, open(tmp, "w", encoding="utf-8"), ensure_ascii=False)
            os.replace(tmp, os.path.join(s.dir, "project.json"))
            if s.rev % 20 == 0:  # 定期留一份備份
                bk = os.path.join(s.dir, "backup"); os.makedirs(bk, exist_ok=True)
                json.dump(project, open(os.path.join(bk, f"project-{time.strftime('%Y%m%d-%H%M%S')}.json"), "w", encoding="utf-8"), ensure_ascii=False)
            s._record_rev(before, project, who, note)
            return True

    # ---------- 歷史版本 ----------
    REV_MERGE_SECS = 120    # 同一個人連續修改（例如拖曳設備）合併成一筆
    REV_KEEP = 500

    def _add_rev(s, rev, project, who, summary, ts, detail=None):
        s.db.execute("INSERT OR REPLACE INTO revs VALUES (?,?,?,?,?,?)", (rev, ts, who or "", summary, json.dumps(detail or {}, ensure_ascii=False),
                                                                     zlib.compress(json.dumps(project, ensure_ascii=False).encode("utf-8"), 6)))

    def _record_rev(s, before, after, who, note):
        now = int(time.time())
        last = s.db.execute("SELECT rev, ts, who, detail FROM revs ORDER BY rev DESC LIMIT 1").fetchone()
        base = before
        if last and not note and last[2] == (who or "") and now - last[1] < s.REV_MERGE_SECS:
            prev = s.db.execute("SELECT data FROM revs WHERE rev < ? ORDER BY rev DESC LIMIT 1", (last[0],)).fetchone()
            base = json.loads(zlib.decompress(prev[0])) if prev else {}
            s.db.execute("DELETE FROM revs WHERE rev=?", (last[0],))
        detail = diff_projects(base or {}, after)
        s._add_rev(s.rev, after, who, note or detail["text"], now, detail)
        n = s.db.execute("SELECT COUNT(*) FROM revs").fetchone()[0]
        if n > s.REV_KEEP: s.db.execute("DELETE FROM revs WHERE rev IN (SELECT rev FROM revs ORDER BY rev LIMIT ?)", (n - s.REV_KEEP,))
        s.db.commit()

    def revs(s, limit=200):
        with s.lock:
            rows = s.db.execute("SELECT rev, ts, who, summary, detail FROM revs ORDER BY rev DESC LIMIT ?", (limit,)).fetchall()
        return [{"rev": r[0], "ts": r[1], "who": r[2], "summary": r[3], "detail": json.loads(r[4] or "{}"), "current": r[0] == s.rev} for r in rows]

    def rev_project(s, rev):
        with s.lock:
            r = s.db.execute("SELECT data, ts FROM revs WHERE rev=?", (int(rev),)).fetchone()
        return (json.loads(zlib.decompress(r[0])), r[1]) if r else (None, None)

    def restore(s, rev, who=""):
        proj, ts = s.rev_project(rev)
        if proj is None: return False
        return s.set_project(proj, None, who, f"還原到 #{rev}（{time.strftime('%m/%d %H:%M', time.localtime(ts))} 的版本）")

    # ---------- 事件 ----------
    def add_event(s, ev):
        text = na.event_line(ev)
        with s.lock:
            cur = s.db.execute("INSERT INTO events(ts, kind, level, dev, port, text, data) VALUES (?,?,?,?,?,?,?)",
                               (int(ev.get("ts") or time.time()), ev["kind"], na.LEVEL.get(ev["kind"], "info"), ev.get("dev") or "", ev.get("port") or "", text,
                                json.dumps(ev, ensure_ascii=False)))
            s.db.commit(); return cur.lastrowid

    def events(s, since_id=0, limit=200, dev=None):
        q, a = "SELECT id, ts, kind, level, dev, port, text FROM events WHERE id > ?", [int(since_id or 0)]
        if dev: q += " AND dev = ?"; a.append(dev)
        with s.lock:
            rows = s.db.execute(q + " ORDER BY id DESC LIMIT ?", a + [int(limit)]).fetchall()
        return [{"id": r[0], "ts": r[1], "kind": r[2], "level": r[3], "dev": r[4], "port": r[5], "text": r[6]} for r in rows]

    # ---------- 網路上看過的設備（新加入／離線） ----------
    def seen_update(s, items, src):
        """items: [{mac, ip, name, wireless, via}]。回傳事件清單（新設備、IP 變更）。第一次收到資料時當作基準，不發「新設備」。"""
        now = int(time.time()); evs = []
        with s.lock:
            # 第一次從某個來源（某台路由器、某台 Switch）讀到的清單當作基準，不算「新加入」
            srcs = s.settings.setdefault("inv_sources", [])
            baseline = not s.db.execute("SELECT 1 FROM seen LIMIT 1").fetchone() or (src and src not in srcs)
            if src and src not in srcs: srcs.append(src); s.save_settings()
            for it in items:
                mac = norm_mac(it.get("mac"))
                if not mac: continue
                ip = it.get("ip") or ""; name = it.get("name") or ""
                r = s.db.execute("SELECT ip, name, first, gone, ips FROM seen WHERE mac=?", (mac,)).fetchone()
                if not r:
                    vendor = ns.oui_vendor(mac.upper())
                    s.db.execute("INSERT INTO seen VALUES (?,?,?,?,?,?,?,?,?,0,?)", (mac, ip, name, vendor, 0 if baseline else now, now, src, it.get("via") or "", 1 if it.get("wireless") else 0, ip))
                    if not baseline: evs.append({"kind": "newdev", "mac": mac, "ip": ip, "name": name or vendor or mac, "ts": now, "detail": f"由 {src} 看到" if src else None})
                else:
                    ips = [x for x in (r[4] or "").split(",") if x]
                    if ip and ip not in ips: ips = (ips + [ip])[-5:]
                    if ip and r[0] and ip != r[0]: evs.append({"kind": "ipchange", "mac": mac, "ip": ip, "name": name or r[1] or mac, "ts": now, "detail": f"原本 {r[0]}"})
                    s.db.execute("UPDATE seen SET ip=COALESCE(NULLIF(?,''), ip), name=COALESCE(NULLIF(?,''), name), last=?, src=?, via=COALESCE(NULLIF(?,''), via), wireless=?, gone=0, ips=? WHERE mac=?",
                                 (ip, name, now, src, it.get("via") or "", 1 if it.get("wireless") else 0, ",".join(ips), mac))
                    if r[3]: evs.append({"kind": "back", "mac": mac, "ip": ip, "name": name or r[1] or mac, "ts": now})
            s.db.commit()
        return evs

    def seen_gone(s, hours, known_macs):
        """圖上的設備（有 MAC）超過 hours 小時沒出現：發一次「很久沒出現」。"""
        now = int(time.time()); evs = []
        with s.lock:
            for mac, ip, name, last in s.db.execute("SELECT mac, ip, name, last FROM seen WHERE gone=0 AND last < ?", (now - hours * 3600,)).fetchall():
                s.db.execute("UPDATE seen SET gone=1 WHERE mac=?", (mac,))
                if mac in known_macs: evs.append({"kind": "gone", "mac": mac, "ip": ip, "name": known_macs[mac] or name or mac, "ts": now, "detail": f"最後出現 {time.strftime('%m/%d %H:%M', time.localtime(last))}"})
            s.db.commit()
        return evs

    def seen_list(s):
        with s.lock:
            rows = s.db.execute("SELECT mac, ip, name, vendor, first, last, src, via, wireless, gone, ips FROM seen ORDER BY last DESC").fetchall()
        return [{"mac": r[0], "ip": r[1], "name": r[2], "vendor": r[3], "first": r[4], "last": r[5], "src": r[6], "via": r[7], "wireless": bool(r[8]), "gone": bool(r[9]),
                 "ips": [x for x in (r[10] or "").split(",") if x]} for r in rows]

    def seen_forget(s, macs):
        with s.lock:
            s.db.executemany("DELETE FROM seen WHERE mac=?", [(norm_mac(m),) for m in macs]); s.db.commit()

    def add_samples(s, rows, speeds=None):
        if not rows: return
        speeds = speeds or {}
        agg = []
        for (t, pid, i, o, up, _ie, _oe) in rows:
            if i is None and o is None: continue
            for res, _ in ROLLUPS:
                agg.append((pid, res, t // res * res, i or 0, o or 0, i or 0, o or 0, up or 0, speeds.get(pid) or 0))
        with s.lock:
            s.db.executemany("INSERT INTO samples VALUES (?,?,?,?,?,?,?)", rows)
            s.db.executemany("INSERT INTO rollup VALUES (?,?,?,1,?,?,?,?,?,?) ON CONFLICT(pid, res, ts) DO UPDATE SET n=n+1, sin=sin+excluded.sin, sout=sout+excluded.sout, "
                             "xin=MAX(xin, excluded.xin), xout=MAX(xout, excluded.xout), upn=upn+excluded.upn, spd=MAX(spd, excluded.spd)", agg)
            s.db.commit()

    def mrtg(s, pid):
        """MRTG 的四張圖：每點 = [時間, 平均進, 平均出, 最大進, 最大出]。"""
        now = int(time.time()); out = {}; spd = 0
        with s.lock:
            for (res, keep), (name, span) in zip(ROLLUPS, MRTG_VIEWS):
                rows = s.db.execute("SELECT ts, sin/n, sout/n, xin, xout, spd FROM rollup WHERE pid=? AND res=? AND ts>=? ORDER BY ts", (pid, res, now - span)).fetchall()
                spd = max([spd] + [r[5] or 0 for r in rows])
                out[name] = {"res": res, "span": span, "points": [[r[0], r[1], r[2], r[3], r[4]] for r in rows]}
        return {"port": pid, "speed": spd, "now": now, "graphs": out}

    def mrtg_device(s, dev_id, view="day"):
        """一台設備所有埠的同一張圖（日／週／月／年）。"""
        views = dict(MRTG_VIEWS); res_of = {n: r for (r, _k), (n, _s) in zip(ROLLUPS, MRTG_VIEWS)}
        if view not in views: view = "day"
        d = next((x for x in s.project.get("devices", []) if x.get("id") == dev_id), None)
        if not d: return {"device": dev_id, "view": view, "ports": {}}
        now = int(time.time()); res = res_of[view]; pids = [p["id"] for p in d.get("ports", [])]; out = {}
        with s.lock:
            for pid in pids:
                rows = s.db.execute("SELECT ts, sin/n, sout/n, xin, xout, spd FROM rollup WHERE pid=? AND res=? AND ts>=? ORDER BY ts", (pid, res, now - views[view])).fetchall()
                if rows:
                    out[pid] = {"speed": max(r[5] or 0 for r in rows), "points": [[r[0], r[1], r[2], r[3], r[4]] for r in rows]}
        return {"device": dev_id, "view": view, "res": res, "span": views[view], "now": now, "ports": out}

    def mrtg_summary(s):
        """所有埠最近 24 小時：平均／最大，以及 30 分鐘一點的小圖。"""
        since = int(time.time()) - 86400; res = {}
        with s.lock:
            for pid, ts, ai, ao, mi, mo, sp in s.db.execute("SELECT pid, ts, sin/n, sout/n, xin, xout, spd FROM rollup WHERE res=1800 AND ts>=? ORDER BY pid, ts", (since,)):
                r = res.setdefault(pid, {"spark": [], "max_in": 0, "max_out": 0, "speed": 0, "_si": 0, "_so": 0})
                r["spark"].append([ts, round(ai or 0), round(ao or 0)])
                r["max_in"] = max(r["max_in"], ai or 0); r["max_out"] = max(r["max_out"], ao or 0); r["speed"] = max(r["speed"], sp or 0)
                r["_si"] += ai or 0; r["_so"] += ao or 0
        for r in res.values():
            n = max(1, len(r["spark"])); r["avg_in"] = r.pop("_si") / n; r["avg_out"] = r.pop("_so") / n
        return res

    def purge(s):
        with s.lock:
            now = int(time.time())
            s.db.execute("DELETE FROM events WHERE ts < ?", (now - 180 * 86400,))
            s.db.execute("DELETE FROM samples WHERE ts < ?", (now - int(s.settings.get("retention_days", 7)) * 86400,))
            for res, keep in ROLLUPS: s.db.execute("DELETE FROM rollup WHERE res=? AND ts < ?", (res, now - keep))
            s.db.commit()

    def history(s, pid, hours=24, points=360):
        since = int(time.time() - hours * 3600)
        with s.lock:
            rows = s.db.execute("SELECT ts, inb, outb, up, ierr, oerr FROM samples WHERE pid=? AND ts>=? ORDER BY ts", (pid, since)).fetchall()
        if len(rows) <= points: return [list(r) for r in rows]
        step = len(rows) / points; out = []
        for i in range(points):
            chunk = rows[int(i * step):int((i + 1) * step)] or [rows[-1]]
            out.append([chunk[-1][0], max(r[1] or 0 for r in chunk), max(r[2] or 0 for r in chunk), min(r[3] for r in chunk), sum(r[4] or 0 for r in chunk), sum(r[5] or 0 for r in chunk)])
        return out

# ───────────────────────── poller ─────────────────────────
OPER, HC_IN, HC_OUT, IN32, OUT32, IERR, OERR, HSPEED = ("1.3.6.1.2.1.2.2.1.8", "1.3.6.1.2.1.31.1.1.1.6", "1.3.6.1.2.1.31.1.1.1.10", "1.3.6.1.2.1.2.2.1.10",
                                                       "1.3.6.1.2.1.2.2.1.16", "1.3.6.1.2.1.2.2.1.14", "1.3.6.1.2.1.2.2.1.20", "1.3.6.1.2.1.31.1.1.1.15")
UPTIME = "1.3.6.1.2.1.1.3.0"
MONITOR_TYPES = {"fw", "router", "sw", "hub", "ap"}

def counter_delta(now, before, wrap):
    """計數器差值。變小時：接近上限才當作繞回，否則是設備重開機／計數歸零，這一次不算（避免流量圖出現假尖峰）。"""
    d = now - before
    if d >= 0: return d
    if wrap == 2 ** 32 and before > wrap * 0.75: return d + wrap
    return None


def too_fast(din, dout, dt_, speed):
    """超過介面速率 1.5 倍的值不可能是真的（計數器異常），丟掉這一點。"""
    return bool(speed) and max(din, dout) * 8 / dt_ > speed * 1.5


PASS_TYPES = {"patch", "seat"}
INFRA_TYPES = {"fw", "router", "sw", "hub", "ap"}

def far_ends(project):
    """每個埠沿著線（穿過配線架、資訊座）走到底的另一端設備：{埠id: 設備}。"""
    owner, port, cab = {}, {}, {}
    for d in project.get("devices", []):
        for p in d.get("ports", []): owner[p["id"]] = d; port[p["id"]] = p
    for c in project.get("cables", []): cab[c.get("a")] = c; cab[c.get("b")] = c
    out = {}
    for pid in cab:
        if pid not in owner: continue
        cur, seen = pid, {pid}
        for _ in range(64):
            c = cab.get(cur)
            if not c: break
            nx = c["b"] if c.get("a") == cur else c.get("a")
            if nx not in owner or nx in seen: break
            seen.add(nx); cur = nx
            d, p = owner[nx], port[nx]
            if d.get("type") in PASS_TYPES and p.get("pair") and p["pair"] not in seen:
                seen.add(p["pair"]); cur = p["pair"]; continue
            break
        if cur != pid and owner.get(cur) is not owner[pid]: out[pid] = owner[cur]
    return out, owner, port


PROBE_EVERY = 3600
PROBE_END_KINDS = {"伺服器", "NAS", "NVR 錄影主機", "印表機"}

def probe_candidates(project, self_set):
    """還沒有 SNMP 監控、但可能有 SNMP 的設備：網路設備，以及伺服器、NAS、NVR、印表機。"""
    out = []
    for d in project.get("devices", []):
        ip = str(d.get("ip") or "").strip()
        if not ip or not re.match(r"^[\w.\-]+$", ip) or ip in self_set: continue
        if (d.get("snmp") or {}).get("host") or (d.get("sshmon") or {}).get("host") or d.get("snmp_probe") is False: continue
        net = d.get("type") in MONITOR_TYPES
        if net and d.get("monitor") is not False: continue            # 已經在輪詢清單裡
        if not net and not (d.get("type") == "end" and d.get("kind") in PROBE_END_KINDS): continue
        out.append(d)
    return out

def snmp_ports(cli):
    """讀實體介面：[(ifIndex, 標籤, 種類, 原始名稱)]。"""
    names = ns.by_index(cli.walk(ns.IF_NAME), ns.IF_NAME); descr = ns.by_index(cli.walk(ns.IF_DESCR), ns.IF_DESCR)
    types = ns.by_index(cli.walk(ns.IF_TYPE), ns.IF_TYPE); speeds = ns.by_index(cli.walk(ns.IF_HSPEED), ns.IF_HSPEED)
    out = []
    for i in sorted(set(names) | set(descr), key=lambda x: int(x) if str(x).isdigit() else 0):
        n = ns.s_(names.get(i)) or ns.s_(descr.get(i))
        it = {"name": n, "descr": ns.s_(descr.get(i)), "type": int(types.get(i) or 0), "speed": int(speeds.get(i) or 0) * 1_000_000}
        if n and ns.is_phys(it): out.append((i, ns.port_label(n), ns.port_kind(it), n))
    return out


class Poller:
    def __init__(s, store, log=print, emit=None):
        s.store, s.log = store, log
        s.emit = emit or (lambda ev: None)
        s.arp = {}           # host → 上次讀 ARP 表的時間
        s.inv_t = 0          # 上次整理「網路上的設備」的時間
        s.probe_t = time.time() - PROBE_EVERY + 90   # 啟動 1～2 分鐘後先試一次 SNMP
        s.probe_force = False; s.probe_last = {"ts": 0, "tried": 0, "found": []}
        s.status = {"ts": 0, "devices": {}, "ports": {}}
        s.prev = {}          # (host, ifIndex) → (t, in, out, ierr, oerr)
        s.ifmaps = {}        # host → (time, {label → ifIndex})
        s.links = {}         # "ip:port" → sm.SshLink（保持連線）
        s.clients = {}       # host → (時間, [用戶端])：路由器上的有線／無線設備，每 5 分鐘更新
        s.thread = None; s.stop_ev = threading.Event(); s.wake = threading.Event()
        s.running = False; s.last_cycle = 0; s.cycle_secs = 0

    def targets(s):
        out = []
        for d in s.store.project.get("devices", []):
            if (d.get("sshmon") or {}).get("host"):
                out.append((d, "ssh://" + d["sshmon"]["host"])); continue
            # 跑 netmap.exe 的這台電腦：直接讀網卡，不需要 SNMP（網段探索建立的設備即使標成不監控也照樣讀）
            if not (d.get("snmp") or {}).get("host") and d.get("ip") and s.store.settings.get("monitor_self", True) and d["ip"] in self_ips():
                out.append((d, "local://" + d["ip"])); continue
            if d.get("monitor") is False: continue
            host = (d.get("snmp") or {}).get("host") or (d.get("ip") if d.get("type") in MONITOR_TYPES else "")
            host = (host or "").strip()
            if host and re.match(r"^[\w.\-]+(:\d+)?$", host): out.append((d, host))
        return out

    def ifmap(s, cli, host):
        cached = s.ifmaps.get(host)
        if cached and time.time() - cached[0] < 3600: return cached[1]
        names = ns.by_index(cli.walk(ns.IF_NAME), ns.IF_NAME); descr = ns.by_index(cli.walk(ns.IF_DESCR), ns.IF_DESCR)
        m = {}
        for i in set(names) | set(descr):
            for n in (ns.s_(names.get(i)), ns.s_(descr.get(i))):
                if not n: continue
                for k in (n, ns.short_if(n), ns.port_label(n)): m.setdefault(k.lower(), i)
        s.ifmaps[host] = (time.time(), m); return m

    def link(s, key):
        c = s.store.ssh_creds(key)
        if not c: raise sm.SshError("沒有這台設備的 SSH 帳密，請在 netmap.exe 重新加入")
        L = s.links.get(key)
        if not L or L.user != c["user"] or L.password != c["password"]:
            if L: L.close()
            ip, port = sm.split_host(key)
            L = s.links[key] = sm.SshLink(ip, port, c["user"], c["password"], c["hostkey"])
        return L

    def poll_local(s, d, host):
        ip = host[8:]; now = time.time(); res = {"dev": {"up": False, "err": "", "last": int(now), "via": "local"}, "ports": {}, "rows": []}
        nics = local_nics()
        if nics is None: res["dev"]["err"] = "讀不到這台電腦的網卡（缺少 psutil）"; return res
        nic = next((n for n, v in nics.items() if ip in v["ips"]), None)
        if not nic: res["dev"]["err"] = f"這台電腦目前沒有 {ip} 這個 IP"; return res
        v = nics[nic]; res["dev"]["up"] = True; t = time.time()
        ports = d.get("ports", []); cabled = {x for c in s.store.project.get("cables", []) for x in (c.get("a"), c.get("b"))}
        p = next((q for q in ports if q.get("ifName") == nic), None) or next((q for q in ports if q["id"] in cabled), None) or (ports[0] if ports else None)
        if not p: return res
        k = (host, nic); prev = s.prev.get(k); s.prev[k] = (t, v["rx"], v["tx"], v["ie"], v["oe"])
        rin = rout = None; die = doe = 0
        if prev and t - prev[0] > 0.5:
            dt_ = t - prev[0]; din, dout = counter_delta(v["rx"], prev[1], 2 ** 64), counter_delta(v["tx"], prev[2], 2 ** 64)
            if din is not None and dout is not None and not too_fast(din, dout, dt_, v["speed"]):
                rin, rout = din * 8 / dt_, dout * 8 / dt_; die, doe = max(0, v["ie"] - prev[3]), max(0, v["oe"] - prev[4])
        res["ports"][p["id"]] = {"up": v["up"], "in": rin, "out": rout, "speed": v["speed"], "util": (max(rin or 0, rout or 0) / v["speed"]) if v["speed"] and rin is not None else None,
                                 "ie": die, "oe": doe, "if": nic}
        if rin is not None: res["rows"].append((int(t), p["id"], rin, rout, 1 if v["up"] is not False else 0, die, doe))
        return res

    def poll_ssh(s, d, host):
        key = host[6:]; now = time.time(); res = {"dev": {"up": False, "err": "", "last": int(now), "via": "ssh"}, "ports": {}, "rows": []}
        try:
            data = sm.read_ports(s.link(key))
        except Exception as e:
            res["dev"]["err"] = str(e) or "SSH 連線失敗"; return res
        res["dev"]["up"] = True; t = time.time()
        if d.get("type") in ("router", "ap", "fw") and d.get("clients") is not False:
            c = s.clients.get(host)
            if not c or time.time() - c[0] > 300:
                try: c = s.clients[host] = (time.time(), sm.read_clients(s.link(key), [(p.get("ifName"), p.get("label")) for p in d.get("ports", []) if p.get("ifName")]))
                except Exception: c = c or (time.time(), [])
            res["dev"]["clients"] = c[1]; res["dev"]["clients_at"] = int(c[0])
        for p in d.get("ports", []):
            ifn = p.get("ifName")
            if not ifn or ifn not in data: continue
            rx, tx, re_, te, up, speed = data[ifn]
            k = (host, ifn); prev = s.prev.get(k); s.prev[k] = (t, rx, tx, re_, te)
            rin = rout = None; die = doe = 0
            if prev and t - prev[0] > 0.5:
                dt_ = t - prev[0]; din, dout = rx - prev[1], tx - prev[2]
                din, dout = counter_delta(rx, prev[1], 2 ** 32), counter_delta(tx, prev[2], 2 ** 32)
                if din is not None and dout is not None and not too_fast(din, dout, dt_, speed):
                    rin, rout = din * 8 / dt_, dout * 8 / dt_
                    die, doe = max(0, re_ - prev[3]), max(0, te - prev[4])
            st = {"up": up, "in": rin, "out": rout, "speed": speed, "util": (max(rin or 0, rout or 0) / speed) if speed and rin is not None else None,
                  "ie": die, "oe": doe, "if": ifn}
            res["ports"][p["id"]] = st
            if rin is not None or up is not None:
                res["rows"].append((int(t), p["id"], rin, rout, 1 if up is not False else 0, die, doe))
        return res

    def poll_device(s, d, host, opts):
        now = time.time(); res = {"dev": {"up": False, "err": "", "last": int(now)}, "ports": {}, "rows": []}
        try:
            cli = ns.make_client(opts, host)
        except Exception as e:
            res["dev"]["err"] = str(e); return res
        try:
            try: up = cli.get([UPTIME, ns.SYS["name"]])
            except ns.SnmpError: up = None
            if not up: raise ns.SnmpError("no response")
            res["dev"]["up"] = True; res["dev"]["uptime"] = up.get(UPTIME)
            pidx = {}
            need_map = [p for p in d.get("ports", []) if p.get("ifIndex") in (None, "") and p.get("side") != 1]
            m = s.ifmap(cli, host) if need_map else {}
            for p in d.get("ports", []):
                if p.get("side") == 1: continue
                ix = p.get("ifIndex")
                if ix in (None, ""): ix = m.get(str(p.get("label", "")).lower())
                if ix not in (None, ""): pidx[p["id"]] = str(ix)
            ixs = sorted(set(pidx.values()), key=lambda x: int(x) if x.isdigit() else 0)
            vals = {}
            cols = [OPER, HC_IN, HC_OUT, IERR, OERR, HSPEED]
            oids = [f"{c}.{i}" for i in ixs for c in cols]
            for k in range(0, len(oids), 36): vals.update(cli.get(oids[k:k + 36]))
            missing = [i for i in ixs if f"{HC_IN}.{i}" not in vals]
            if missing:
                o2 = [f"{c}.{i}" for i in missing for c in (IN32, OUT32)]
                for k in range(0, len(o2), 36): vals.update(cli.get(o2[k:k + 36]))
            t = time.time(); cache = {}
            for i in ixs:
                inc = vals.get(f"{HC_IN}.{i}", vals.get(f"{IN32}.{i}")); outc = vals.get(f"{HC_OUT}.{i}", vals.get(f"{OUT32}.{i}"))
                ie, oe = vals.get(f"{IERR}.{i}", 0) or 0, vals.get(f"{OERR}.{i}", 0) or 0
                wrap = 2 ** 64 if f"{HC_IN}.{i}" in vals else 2 ** 32
                key = (host, i); prev = s.prev.get(key); s.prev[key] = (t, inc, outc, ie, oe)
                rin = rout = None; die = doe = 0
                if prev and inc is not None and prev[1] is not None and t - prev[0] > 0.5:
                    dt_ = t - prev[0]
                    din, dout = counter_delta(inc, prev[1], wrap), counter_delta(outc or 0, prev[2] or 0, wrap)
                    if din is not None and dout is not None and not too_fast(din, dout, dt_, (vals.get(f"{HSPEED}.{i}") or 0) * 1_000_000):
                        rin, rout = din * 8 / dt_, dout * 8 / dt_
                        die, doe = max(0, ie - prev[3]), max(0, oe - prev[4])
                speed = (vals.get(f"{HSPEED}.{i}") or 0) * 1_000_000
                oper = vals.get(f"{OPER}.{i}")
                cache[i] = {"up": None if oper is None else oper == 1, "in": rin, "out": rout, "speed": speed,
                            "util": (max(rin or 0, rout or 0) / speed) if speed and rin is not None else None, "ie": die, "oe": doe, "if": i}
            for pid, i in pidx.items():
                st = cache.get(i)
                if not st: continue
                res["ports"][pid] = st
                if st["in"] is not None or st["up"] is not None:
                    res["rows"].append((int(t), pid, st["in"], st["out"], 1 if st["up"] else 0, st["ie"], st["oe"]))
            # 路由器／防火牆／L3 Switch 的 ARP 表：每 10 分鐘讀一次，用來發現新加入、很久沒出現的設備
            if s.store.settings.get("inv_enabled", True) and d.get("type") in ("router", "fw", "sw") and time.time() - s.arp.get(host, 0) > 600:
                s.arp[host] = time.time()
                try:
                    arp = cli.walk(ns.ARP, max_rows=4000); items = []
                    for o, v in arp.items():
                        ipx = ".".join(o.split(".")[-4:]); mac = ns.mac_of(v)
                        if mac and not ipx.startswith(("224.", "239.", "255.")) and not ipx.endswith(".255"): items.append({"mac": mac, "ip": ipx})
                    res["inv"] = items
                except Exception:
                    pass
        except Exception as e:
            res["dev"]["err"] = "沒有回應" if "timeout" in str(e) or "no response" in str(e) else str(e)
        finally:
            try: cli.close()
            except Exception: pass
        return res

    def cycle(s):
        t0 = time.time(); opts = s.store.snmp_opts(); tg = s.targets()
        devs, ports, rows, inv = {}, {}, [], []
        if tg:
            with ThreadPoolExecutor(max_workers=min(16, len(tg))) as ex:
                for (d, host), r in zip(tg, ex.map(lambda x: s.poll_ssh(x[0], x[1]) if x[1].startswith("ssh://") else s.poll_local(x[0], x[1]) if x[1].startswith("local://") else s.poll_device(x[0], x[1], opts), tg)):
                    devs[d["id"]] = {**r["dev"], "host": host}; ports.update(r["ports"]); rows += r["rows"]
                    if r.get("inv"): inv.append((d.get("name") or host, r["inv"]))
                    if host.startswith("ssh://") and r["dev"].get("clients") and r["dev"].get("clients_at", 0) > s.arp.get(host, 0):
                        s.arp[host] = r["dev"]["clients_at"]
                        inv.append((d.get("name") or host, [{"mac": c["mac"], "ip": c["ip"], "name": c.get("name"), "wireless": c.get("wireless"), "via": c.get("band") or c.get("iface")} for c in r["dev"]["clients"]]))
        s.store.add_samples(rows, {pid: p.get("speed") for pid, p in ports.items()})
        old = s.status
        s.status = {"ts": int(time.time()), "devices": devs, "ports": ports}
        try: s.transitions(old, s.status)
        except Exception as e: s.log(f"事件判斷錯誤：{e}")
        try: s.inventory(inv)
        except Exception as e: s.log(f"設備清單錯誤：{e}")
        if s.store.settings.get("snmp_autoprobe", True) and (s.probe_force or time.time() - s.probe_t > PROBE_EVERY):
            s.probe_force = False; s.probe_t = time.time()
            try: s.autoprobe(opts)
            except Exception as e: s.log(f"自動偵測 SNMP 錯誤：{e}")
        s.last_cycle = time.time(); s.cycle_secs = round(time.time() - t0, 2)
        down = [d for d in devs.values() if not d["up"]]
        s.log(f"輪詢完成：{len(devs)} 台設備（{len(down)} 台沒回應）、{len(ports)} 個埠，{s.cycle_secs} 秒")
        if int(t0) % 3600 < max(60, int(s.store.settings.get("interval", 60))): s.store.purge()

    def transitions(s, old, new):
        """和上一輪比：SNMP／SSH 設備沒回應、恢復；接到網路設備的埠（主幹）離線、恢復。"""
        if not old.get("ts"): return
        proj = s.store.project; byid = {d["id"]: d for d in proj.get("devices", [])}
        far, owner, port = far_ends(proj)
        for did, st in new["devices"].items():
            o = old["devices"].get(did)
            if not o or o.get("up") == st.get("up") or st.get("via") == "local": continue
            d = byid.get(did) or {}
            s.emit({"kind": "snmp_up" if st.get("up") else "snmp_down", "dev": did, "name": d.get("name", ""), "ip": d.get("ip", ""), "ts": new["ts"],
                    "detail": None if st.get("up") else (st.get("err") or "沒有回應")})
        for pid, st in new["ports"].items():
            o = old["ports"].get(pid)
            if not o or o.get("up") is None or st.get("up") is None or o["up"] == st["up"]: continue
            p, d, fd = port.get(pid) or {}, owner.get(pid) or {}, far.get(pid)
            if p.get("alert") in (False, "off"): continue
            if not (p.get("alert") in (True, "on") or (fd and fd.get("type") in INFRA_TYPES) or (fd and fd.get("type") == "end" and fd.get("kind") in ("伺服器", "NAS", "NVR 錄影主機", "ISP 數據機"))): continue
            s.emit({"kind": "port_up" if st["up"] else "port_down", "dev": d.get("id"), "port": pid, "name": d.get("name", ""), "port_name": f"埠 {p.get('label', '')}" + (f" → {fd.get('name')}" if fd else ""), "ts": new["ts"]})

    def inventory(s, inv):
        st = s.store.settings
        if not st.get("inv_enabled", True): return
        now = time.time()
        if now - s.inv_t > 600:   # 這台電腦自己的 ARP 表
            s.inv_t = now
            try:
                me = ns.arp_table()
                if me: inv.append(("netmap 主機", [{"mac": m, "ip": ip} for ip, m in me.items()]))
            except Exception: pass
            known = {norm_mac(d.get("mac")): d.get("name", "") for d in s.store.project.get("devices", []) if norm_mac(d.get("mac"))}
            for ev in s.store.seen_gone(int(st.get("inv_gone_hours") or 24), known): s.emit(ev)
        for src, items in inv:
            for ev in s.store.seen_update(items, src): s.emit(ev)

    def autoprobe(s, opts):
        """用已設定的 SNMP 帳密試圖上還沒監控的設備；有回應就開始監控，並用設備回報的介面補上埠號。"""
        cands = probe_candidates(s.store.project, self_ips())
        s.probe_last = {"ts": int(time.time()), "tried": len(cands), "found": []}
        if not cands: return
        def try_one(d):
            cli = None
            try:
                cli = ns.make_client(opts, d["ip"].strip(), quick=True)
                r = cli.get([ns.SYS["name"], ns.SYS["descr"]])
                if not r: return None
                ports = []
                try: ports = snmp_ports(cli)
                except Exception: pass
                return {"name": ns.s_(r.get(ns.SYS["name"])), "descr": ns.s_(r.get(ns.SYS["descr"])), "ports": ports}
            except Exception:
                return None
            finally:
                try: cli and cli.close()
                except Exception: pass
        with ThreadPoolExecutor(max_workers=min(16, len(cands))) as ex:
            res = dict(zip([d["id"] for d in cands], ex.map(try_one, cands)))
        hits = {k: v for k, v in res.items() if v}
        if not hits: return
        with s.store.lock: proj = json.loads(json.dumps(s.store.project))
        cabled = {x for c in proj.get("cables", []) for x in (c.get("a"), c.get("b"))}
        found = []
        for d in proj.get("devices", []):
            h = hits.get(d["id"])
            if not h: continue
            d["snmp"] = {"host": d["ip"].strip()}; d.pop("monitor", None)
            ports = d.setdefault("ports", []); added = mapped = 0
            if h["ports"]:
                by = {}
                for p in ports:
                    for k in (str(p.get("label", "")).lower(), str(p.get("ifName", "")).lower()): by.setdefault(k, p)
                used = set()
                for ix, lab, kind, raw in h["ports"]:
                    p = by.get(lab.lower()) or by.get(raw.lower()) or by.get(ns.short_if(raw).lower())
                    if p and p["id"] not in used: p["ifIndex"] = ix; used.add(p["id"]); mapped += 1; continue
                    ports.append({"id": ns.nid("p"), "label": lab, "kind": kind, "poe": False, "mode": "access", "vlan": "", "tagged": "", "lag": "", "note": raw if raw != lab else "", "ifIndex": ix}); added += 1
                # 網段探索建立的「WAN／ETH1」這類佔位埠：沒接線又對不上就拿掉
                ports[:] = [p for p in ports if p.get("ifIndex") not in (None, "") or p["id"] in cabled or p.get("side") is not None]
            if h["descr"] and not d.get("model"):
                br = ns.brand_of({"sysDescr": h["descr"]})
                if br and not d.get("brand"): d["brand"] = br
            nm = h["name"] if re.match(r"^(\d+\.){3}\d+$", h["name"] or "") else (h["name"] or "").split(".")[0]
            if nm and re.match(r"^(\d+\.){3}\d+$|^(路由器|AP|Switch|設備)\b", d.get("name", "")): d["name"] = nm[:40]
            unm = [p for p in ports if p["id"] in cabled and p.get("ifIndex") in (None, "")]
            found.append({"dev": d["id"], "name": d.get("name"), "ip": d["ip"], "ports": len(h["ports"]), "added": added, "mapped": mapped, "unmapped": len(unm)})
        s.store.set_project(proj, None, "自動偵測 SNMP", f"自動偵測到 SNMP：{'、'.join(f['name'] for f in found)}")
        s.ifmaps.clear(); s.probe_last["found"] = found
        for f in found:
            s.emit({"kind": "snmp_found", "dev": f["dev"], "name": f["name"], "ip": f["ip"], "ts": int(time.time()),
                    "detail": f"讀到 {f['ports']} 個埠" + (f"，新增 {f['added']} 個" if f["added"] else "") + (f"；有 {f['unmapped']} 個已接線的埠對不上，請在設備屬性改成設備上的埠名稱，或重新掃描" if f["unmapped"] else "")})
        s.wake.set()

    def run(s):
        s.running = True
        while not s.stop_ev.is_set():
            try: s.cycle()
            except Exception as e: s.log(f"輪詢錯誤：{e}")
            s.wake.wait(max(10, int(s.store.settings.get("interval", 60)))); s.wake.clear()
        s.running = False

    def start(s):
        if s.thread and s.thread.is_alive(): return
        s.stop_ev.clear(); s.thread = threading.Thread(target=s.run, daemon=True, name="poller"); s.thread.start()

    def stop(s):
        s.stop_ev.set(); s.wake.set()
        for L in list(s.links.values()): L.close()
        s.links.clear()

    def poke(s):
        s.ifmaps.clear(); s.wake.set()

# ───────────────────────── 權限 ─────────────────────────
def hash_pw(pw, salt=None, it=200_000):
    salt = salt or secrets.token_hex(16)
    return f"pbkdf2${it}${salt}${hashlib.pbkdf2_hmac('sha256', pw.encode('utf-8'), bytes.fromhex(salt), it).hex()}"

def check_pw(pw, stored):
    try:
        _k, it, salt, h = stored.split("$")
        return hmac.compare_digest(hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), bytes.fromhex(salt), int(it)).hex(), h)
    except Exception:
        return False

class Auth:
    """管理員登入的 session（只存在記憶體，服務重開要重新登入）與登入失敗限制。"""
    TTL = 12 * 3600
    def __init__(s): s.sessions = {}; s.fails = {}; s.lock = threading.Lock()
    def new(s):
        t = secrets.token_urlsafe(24)
        with s.lock: s.sessions[t] = time.time() + s.TTL
        return t
    def valid(s, t):
        if not t: return False
        with s.lock:
            exp = s.sessions.get(t)
            if not exp or exp < time.time(): s.sessions.pop(t, None); return False
            s.sessions[t] = time.time() + s.TTL; return True
    def drop(s, t=None):
        with s.lock:
            if t: s.sessions.pop(t, None)
            else: s.sessions.clear()
    def blocked(s, ip):
        with s.lock:
            f = [t for t in s.fails.get(ip, []) if t > time.time() - 600]; s.fails[ip] = f
            return len(f) >= 5
    def failed(s, ip):
        with s.lock: s.fails.setdefault(ip, []).append(time.time())

LOGIN_HTML = """<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>netmap 登入</title><style>
:root{--bg:#F4F6F9;--card:#fff;--ink:#16202B;--mute:#5B6878;--line:#D9DFE7;--acc:#2563EB}
@media (prefers-color-scheme:dark){:root{--bg:#0F141B;--card:#18202A;--ink:#E6EBF1;--mute:#9AA7B6;--line:#2A3441;--acc:#4F8BFF}}
body{margin:0;min-height:100vh;display:grid;place-items:center;background:var(--bg);color:var(--ink);font:15px/1.6 system-ui,-apple-system,"Segoe UI","Microsoft JhengHei",sans-serif}
form{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:28px 26px;width:min(360px,calc(100vw - 32px));box-sizing:border-box}
h1{font-size:19px;margin:0 0 6px}p{color:var(--mute);margin:0 0 18px;font-size:13.5px}
input{width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid var(--line);border-radius:9px;background:transparent;color:inherit;font:inherit}
button{margin-top:12px;width:100%;padding:10px;border:0;border-radius:9px;background:var(--acc);color:#fff;font:inherit;font-weight:600;cursor:pointer}
.err{color:#D9443A;font-size:13px;min-height:20px;margin-top:8px}</style></head><body>
<form id="f"><h1>機房線路對應圖</h1><p>這個監控服務需要登入才能查看。沒有密碼的話，請向管理員要一個「檢視連結」。</p>
<input type="password" id="pw" placeholder="管理密碼" autocomplete="current-password" autofocus aria-label="管理密碼"><button>登入</button><div class="err" id="e"></div></form>
<script>document.getElementById('f').onsubmit=async e=>{e.preventDefault();const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json','X-Netmap':'1'},body:JSON.stringify({password:document.getElementById('pw').value})});
if(r.ok)location.replace('/'+location.hash);else{const j=await r.json().catch(()=>({}));document.getElementById('e').textContent=j.error||'密碼不對'}}</script></body></html>"""


# ───────────────────────── HTTP ─────────────────────────
class Handler(http.server.BaseHTTPRequestHandler):
    server_version = f"netmap/{VERSION}"
    def log_message(s, fmt, *a): pass

    def _local(s):
        ip = s.client_address[0]
        return ip.startswith("127.") or ip == "::1" or ip in local_ips()

    def _send(s, code, body, ctype="application/json; charset=utf-8", extra=None):
        if isinstance(body, (dict, list)): body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        elif isinstance(body, str): body = body.encode("utf-8")
        s.send_response(code); s.send_header("Content-Type", ctype); s.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            for vv in (v if isinstance(v, list) else [v]): s.send_header(k, vv)
        s.send_header("Cache-Control", "no-store"); s.send_header("X-Content-Type-Options", "nosniff"); s.end_headers(); s.wfile.write(body)

    def _cookie(s, name):
        for part in (s.headers.get("Cookie") or "").split(";"):
            k, _, v = part.strip().partition("=")
            if k == name: return urllib.parse.unquote(v)
        return ""

    def _detect_origin(s):
        """允許線上版偵測時，回傳可以放行的 Origin；否則 None。"""
        o = s.headers.get("Origin") or ""
        if s.server.store.settings.get("web_detect") and o in DETECT_ORIGINS and s._local(): return o
        return None

    # 權限：服務主機本身永遠是管理員；其他電腦要登入。沒設密碼時沿用「允許內網其他電腦編輯」。
    def is_admin(s): return s._local() or s.server.auth.valid(s._cookie("nm_a"))
    def can_edit(s):
        st = s.server.store.settings
        return s.is_admin() or (bool(st.get("lan_edit")) and not st.get("admin_hash"))
    def view_ok(s, token=None):
        st = s.server.store.settings
        if s.is_admin() or not st.get("view_required"): return True
        t = token or s._cookie("nm_v")
        return bool(t and st.get("view_token") and hmac.compare_digest(t, st["view_token"]))
    def who(s):
        name = urllib.parse.unquote(s.headers.get("X-Netmap-User") or "")[:40].strip()
        place = "服務主機" if s._local() else s.client_address[0]
        return f"{name}（{place}）" if name else place

    def body_json(s, limit=50 * 1024 * 1024):
        n = int(s.headers.get("Content-Length") or 0)
        if n > limit: raise ValueError("too large")
        return json.loads(s.rfile.read(n).decode("utf-8") or "{}") if n else {}

    def do_OPTIONS(s):
        o = s._detect_origin()
        if not o or urllib.parse.urlparse(s.path).path != "/api/ping": return s._send(403, {"error": "forbidden"})
        s._send(204, b"", "text/plain", {"Access-Control-Allow-Origin": o, "Vary": "Origin", "Access-Control-Allow-Methods": "GET",
                                          "Access-Control-Allow-Private-Network": "true", "Access-Control-Max-Age": "600"})

    def do_GET(s):
        st, po, sv = s.server.store, s.server.poller, getattr(s.server, "service", None)
        u = urllib.parse.urlparse(s.path); q = urllib.parse.parse_qs(u.query)
        arg = lambda k, d="": (q.get(k) or [d])[0]
        if u.path == "/api/ping":
            o = s._detect_origin()
            if o: return s._send(200, {"ok": True, "version": VERSION, "port": st.settings.get("port"), "detect": True},
                                 extra={"Access-Control-Allow-Origin": o, "Vary": "Origin", "Access-Control-Allow-Private-Network": "true"})
            return s._send(200, {"ok": True, "version": VERSION})
        if u.path in ("/", "/index.html"):
            tok = arg("t")
            if tok:   # 檢視連結：記在 cookie 裡，網址列不留 token
                if s.view_ok(tok):
                    return s._send(302, b"", "text/plain", {"Location": "/", "Set-Cookie": f"nm_v={urllib.parse.quote(tok)}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Lax"})
                return s._send(403, LOGIN_HTML.replace("請向管理員要一個「檢視連結」。", "這個檢視連結已經失效，請向管理員要新的連結。"), "text/html; charset=utf-8")
            if not s.view_ok(): return s._send(401, LOGIN_HTML, "text/html; charset=utf-8")
            p = web_index()
            if not p: return s._send(500, "找不到網頁檔（web/index.html）", "text/plain; charset=utf-8")
            html = open(p, encoding="utf-8").read()
            with st.lock: boot = {"rev": st.rev, "project": st.project, "interval": st.settings.get("interval", 60), "edit": s.can_edit(), "version": VERSION, "host": socket.gethostname(),
                                      "self_ips": sorted(self_ips()) if st.settings.get("monitor_self", True) else [],
                                      "admin": s.is_admin(), "local": s._local(), "auth": bool(st.settings.get("admin_hash")), "login": s.server.auth.valid(s._cookie("nm_a"))}
            inj = "<script>window.NETMAP_SERVER=" + json.dumps(boot, ensure_ascii=False).replace("</", "<\\/") + ";</script>"
            html = html.replace("</head>", inj + "\n</head>", 1)
            return s._send(200, html, "text/html; charset=utf-8")
        if not u.path.startswith("/api/"): return s._send(404, {"error": "not found"})
        if not s.view_ok(): return s._send(401, {"error": "需要登入或檢視連結"})
        if u.path == "/api/project":
            with st.lock: return s._send(200, {"rev": st.rev, "project": st.project})
        if u.path == "/api/status":
            stat = po.status
            last_ev = st.events(0, 1)
            return s._send(200, {"rev": st.rev, "ts": stat.get("ts", 0), "interval": st.settings.get("interval", 60), "running": po.running,
                                 "devices": stat.get("devices", {}), "ports": stat.get("ports", {}), "edit": s.can_edit(), "admin": s.is_admin(),
                                 "ping": sv.pinger.snapshot() if sv else {}, "ping_on": bool(st.settings.get("ping_enabled", True)),
                                 "ev": last_ev[0]["id"] if last_ev else 0})
        if u.path == "/api/pinghist":
            snap = sv.pinger.snapshot(hist=True) if sv else {}
            return s._send(200, snap.get(arg("id")) or {})
        if u.path == "/api/events":
            return s._send(200, {"events": st.events(arg("since", "0"), min(1000, int(arg("limit", "200") or 200)), arg("dev") or None)})
        if u.path == "/api/revs":
            return s._send(200, {"rev": st.rev, "revs": st.revs(min(500, int(arg("limit", "200") or 200)))})
        if u.path == "/api/revs/get":
            proj, ts = st.rev_project(arg("rev", "0") or 0)
            return s._send(200, {"rev": int(arg("rev", "0") or 0), "ts": ts, "project": proj}) if proj is not None else s._send(404, {"error": "找不到這個版本"})
        if u.path == "/api/seen":
            return s._send(200, {"items": st.seen_list(), "enabled": bool(st.settings.get("inv_enabled", True)), "gone_hours": st.settings.get("inv_gone_hours", 24)})
        if u.path == "/api/settings":
            if not s.is_admin(): return s._send(403, {"error": "需要管理員權限"})
            return s._send(200, sv.public_settings(s.headers.get("Host")) if sv else {})
        if u.path == "/api/history":
            pid = arg("port"); hours = float(arg("hours", "24"))
            return s._send(200, {"port": pid, "points": st.history(pid, min(max(hours, 0.1), 24 * 31))})
        if u.path == "/api/mrtg":
            return s._send(200, st.mrtg(arg("port")))
        if u.path.startswith("/api/flow/"):
            if not sv: return s._send(404, {"error": "flow not available"})
            mins = max(5, min(60 * 24 * 31, int(arg("min", "60") or 60))); exp = arg("exp", "auto")
            if u.path == "/api/flow/status": return s._send(200, sv.flow_status())
            if u.path == "/api/flow/top": return s._send(200, sv.flow.top(mins, exp))
            if u.path == "/api/flow/host": return s._send(200, sv.flow.host(arg("ip"), mins, exp))
            return s._send(404, {"error": "not found"})
        if u.path == "/api/mrtg/device":
            return s._send(200, st.mrtg_device(arg("id"), arg("view", "day")))
        if u.path == "/api/mrtg/summary":
            return s._send(200, {"ports": st.mrtg_summary()})
        s._send(404, {"error": "not found"})

    def _mutating(s):
        """修改用的請求都要帶 X-Netmap 標頭（別的網站的表單或腳本帶不了，防 CSRF）。"""
        if s.headers.get("X-Netmap") != "1": s._send(403, {"error": "missing header"}); return False
        return True

    def do_POST(s):
        st, sv = s.server.store, getattr(s.server, "service", None)
        path = urllib.parse.urlparse(s.path).path
        if not s._mutating(): return
        try: body = s.body_json(1024 * 1024)
        except Exception: return s._send(400, {"error": "bad json"})
        ip = s.client_address[0]
        if path == "/api/login":
            if s.server.auth.blocked(ip): return s._send(429, {"error": "嘗試太多次，請 10 分鐘後再試"})
            h = st.settings.get("admin_hash")
            if not h or not check_pw(str(body.get("password") or ""), h):
                s.server.auth.failed(ip); time.sleep(0.6); return s._send(401, {"error": "密碼不對" if h else "還沒有設定管理密碼"})
            t = s.server.auth.new()
            return s._send(200, {"ok": True}, extra={"Set-Cookie": f"nm_a={t}; Path=/; HttpOnly; SameSite=Strict"})
        if path == "/api/logout":
            s.server.auth.drop(s._cookie("nm_a"))
            return s._send(200, {"ok": True}, extra={"Set-Cookie": "nm_a=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict"})
        if not s.view_ok(): return s._send(401, {"error": "需要登入"})
        if path == "/api/revs/restore":
            if not s.can_edit(): return s._send(403, {"error": "需要編輯權限"})
            if not st.restore(body.get("rev"), s.who()): return s._send(404, {"error": "找不到這個版本"})
            s.server.poller.ifmaps.clear()
            with st.lock: return s._send(200, {"rev": st.rev, "project": st.project})
        if path == "/api/seen/forget":
            if not s.can_edit(): return s._send(403, {"error": "需要編輯權限"})
            st.seen_forget(body.get("macs") or []); return s._send(200, {"ok": True})
        if path == "/api/alerts/test":
            if not s.is_admin(): return s._send(403, {"error": "需要管理員權限"})
            if not sv: return s._send(500, {"error": "no service"})
            res = sv.notifier.deliver([{"kind": "test", "name": "netmap", "ts": int(time.time()), "detail": f"來自 {socket.gethostname()}，通知設定正常"}], only=body.get("id"))
            return s._send(200, {"results": res})
        if path == "/api/snmp/probe":
            if not s.is_admin(): return s._send(403, {"error": "需要管理員權限"})
            s.server.poller.probe_force = True; s.server.poller.wake.set()
            return s._send(200, {"ok": True, "candidates": len(probe_candidates(st.project, self_ips()))})
        if path == "/api/ping/now":
            if sv: sv.pinger.wake.set()
            return s._send(200, {"ok": True})
        s._send(404, {"error": "not found"})

    def do_PUT(s):
        st, sv = s.server.store, getattr(s.server, "service", None)
        path = urllib.parse.urlparse(s.path).path
        if not s._mutating(): return
        if path == "/api/settings":
            if not s.is_admin(): return s._send(403, {"error": "需要管理員權限"})
            try: body = s.body_json(1024 * 1024)
            except Exception: return s._send(400, {"error": "bad json"})
            err = sv.update_settings(body) if sv else "no service"
            if err: return s._send(400, {"error": err})
            return s._send(200, sv.public_settings(s.headers.get("Host")))
        if path != "/api/project": return s._send(404, {"error": "not found"})
        if not s.can_edit(): return s._send(403, {"error": "需要管理員登入才能編輯" if st.settings.get("admin_hash") else "這台電腦設定為只能在服務主機上編輯"})
        try: body = s.body_json()
        except ValueError: return s._send(413, {"error": "too large"})
        except Exception: return s._send(400, {"error": "bad json"})
        proj = body.get("project")
        if not isinstance(proj, dict) or not isinstance(proj.get("devices"), list): return s._send(400, {"error": "bad project"})
        if not st.set_project(proj, body.get("rev"), s.who()):
            with st.lock: return s._send(409, {"rev": st.rev, "project": st.project})
        s.server.poller.ifmaps.clear()
        s._send(200, {"rev": st.rev})

class Service:
    """監控服務：HTTP + 輪詢 + 心跳 + 告警。GUI 與命令列共用。"""
    def __init__(s, store=None, log=print):
        s.store = store or Store(); s.log = log
        s.poller = Poller(s.store, log, emit=s.emit); s.httpd = None; s.thread = None; s._flow = None
        s.auth = Auth()
        s.notifier = na.Notifier(lambda: s.store.settings.get("alerts"), s.resolve_channel, log)
        s.pinger = na.Pinger(lambda: s.store.project.get("devices", []), lambda: s.store.settings, s.emit, log)

    # ---------- 事件與告警 ----------
    def emit(s, ev):
        try: s.store.add_event(ev)
        except Exception as e: s.log(f"事件寫入失敗：{e}")
        if ev["kind"] in ("down", "port_down", "newdev", "gone", "snmp_down"): s.log("事件：" + na.event_line(ev).split(" ", 1)[-1])
        s.notifier.push(ev)

    def resolve_channel(s, ch):
        c = dict(ch)
        for k in na.SECRET.get(ch.get("type"), ()): c[k] = unprotect(ch.get(k))
        return c

    def public_settings(s, host=None):
        st = s.store.settings; a = st.get("alerts") or {}
        chans = []
        for ch in a.get("channels") or []:
            c = {k: v for k, v in ch.items() if k not in na.SECRET.get(ch.get("type"), ())}
            c["secret"] = {k: bool(ch.get(k)) for k in na.SECRET.get(ch.get("type"), ())}
            c["last"] = s.notifier.results.get(ch.get("id"))
            chans.append(c)
        port = int(st.get("port", 8080)); tok = st.get("view_token") or ""
        hosts = [h for h in [((host or "").split(":")[0])] if h and not h.startswith("127.") and h != "localhost"] + [ip for ip in local_ips()]
        return {"ping_enabled": st.get("ping_enabled", True), "ping_interval": st.get("ping_interval", 30), "ping_fails": st.get("ping_fails", 2),
                "ping_slow_ms": st.get("ping_slow_ms", 200), "ping_method": na.ping_method(),
                "inv_enabled": st.get("inv_enabled", True), "inv_gone_hours": st.get("inv_gone_hours", 24),
                "snmp_autoprobe": st.get("snmp_autoprobe", True), "snmp_probe": dict(s.poller.probe_last, candidates=len(probe_candidates(s.store.project, self_ips())), next=int(s.poller.probe_t + PROBE_EVERY)),
                "alerts": {"enabled": bool(a.get("enabled")), "site": a.get("site", ""), "on": a.get("on") or {}, "channels": chans},
                "channel_types": {k: {"name": v["name"], "fields": [[f, l, sec] for f, l, sec in v["fields"]]} for k, v in na.CHANNELS.items()},
                "auth": {"has_password": bool(st.get("admin_hash")), "view_required": bool(st.get("view_required")), "lan_edit": bool(st.get("lan_edit")),
                         "view_links": [f"http://{h}:{port}/?t={tok}" for h in dict.fromkeys(hosts)] if tok else []}}

    def update_settings(s, b):
        st = s.store.settings
        num = lambda v, lo, hi, d: max(lo, min(hi, int(float(v)))) if str(v).strip() not in ("", "None") else d
        try:
            if "ping_enabled" in b: st["ping_enabled"] = bool(b["ping_enabled"])
            if "ping_interval" in b: st["ping_interval"] = num(b["ping_interval"], 5, 3600, 30)
            if "ping_fails" in b: st["ping_fails"] = num(b["ping_fails"], 1, 20, 2)
            if "ping_slow_ms" in b: st["ping_slow_ms"] = num(b["ping_slow_ms"], 10, 10000, 200)
            if "inv_enabled" in b: st["inv_enabled"] = bool(b["inv_enabled"])
            if "snmp_autoprobe" in b: st["snmp_autoprobe"] = bool(b["snmp_autoprobe"])
            if "inv_gone_hours" in b: st["inv_gone_hours"] = num(b["inv_gone_hours"], 1, 24 * 90, 24)
            if "lan_edit" in b: st["lan_edit"] = bool(b["lan_edit"])
            if "view_required" in b: st["view_required"] = bool(b["view_required"])
        except (TypeError, ValueError):
            return "數字格式不對"
        pw = b.get("password")
        if isinstance(pw, dict):
            if pw.get("clear"): st["admin_hash"] = ""; s.auth.drop()
            elif pw.get("new") is not None:
                if len(str(pw["new"])) < 6: return "管理密碼至少 6 個字"
                st["admin_hash"] = hash_pw(str(pw["new"])); s.auth.drop()
        if b.get("regen_token") or (st.get("view_required") and not st.get("view_token")): st["view_token"] = secrets.token_urlsafe(18)
        if b.get("clear_token"): st["view_token"] = ""
        if isinstance(b.get("alerts"), dict):
            na_ = b["alerts"]; cur = st.setdefault("alerts", json.loads(json.dumps(DEFAULT_SETTINGS["alerts"])))
            if "enabled" in na_: cur["enabled"] = bool(na_["enabled"])
            if "site" in na_: cur["site"] = str(na_["site"])[:40]
            if isinstance(na_.get("on"), dict): cur["on"] = {k: bool(v) for k, v in na_["on"].items()}
            if isinstance(na_.get("channels"), list):
                old = {c.get("id"): c for c in cur.get("channels") or []}; out = []
                for c in na_["channels"]:
                    t = c.get("type")
                    if t not in na.CHANNELS: continue
                    cid = c.get("id") or ns.nid("ch"); prev = old.get(cid) or {}
                    o = {"id": cid, "type": t, "name": str(c.get("name") or na.CHANNELS[t]["name"])[:40], "on": c.get("on") is not False}
                    for f, _l, sec in na.CHANNELS[t]["fields"]:
                        if sec:
                            v = c.get(f)
                            o[f] = protect(str(v)) if v not in (None, "") else ("" if c.get("clear_" + f) else prev.get(f, ""))
                        else: o[f] = str(c.get(f) or "")[:300]
                    out.append(o)
                cur["channels"] = out
        s.store.save_settings()
        s.pinger.wake.set()
        return None

    # ---------- 流量明細（NetFlow／IPFIX／sFlow） ----------
    def known_ips(s):
        return {d.get("ip") for d in s.store.project.get("devices", []) if d.get("ip")}

    @property
    def flow(s):
        if s._flow is None:
            st = s.store.settings
            s._flow = nf.FlowCollector(s.store.dir, int(st.get("flow_port") or 2055), int(st.get("sflow_port") or 6343), known_ips=s.known_ips, log=s.log)
        return s._flow

    def start_flow(s):
        st = s.store.settings; f = s.flow
        f.ports = {"netflow": int(st.get("flow_port") or 0), "sflow": int(st.get("sflow_port") or 0)}
        return f.start()

    def stop_flow(s):
        if s._flow and s._flow.running: s._flow.stop(); s.log("流量收集已停止")

    def flow_status(s):
        st = dict(s.flow.status()); st["enabled"] = bool(s.store.settings.get("flow_enabled")); st["collector_ips"] = local_ips()
        return st

    @property
    def running(s): return s.httpd is not None

    def start(s):
        if s.httpd: return
        port = int(s.store.settings.get("port", 8080))
        httpd = http.server.ThreadingHTTPServer(("0.0.0.0", port), Handler)
        httpd.daemon_threads = True; httpd.store = s.store; httpd.poller = s.poller; httpd.auth = s.auth
        httpd.service = s
        s.httpd = httpd; s.thread = threading.Thread(target=httpd.serve_forever, daemon=True, name="http"); s.thread.start()
        s.poller.start(); s.pinger.start()
        s.log(f"服務已啟動：http://{local_ips()[0]}:{port}/")
        if s.store.settings.get("flow_enabled") and not (s._flow and s._flow.running): s.start_flow()

    def stop(s):
        s.poller.stop(); s.pinger.stop(); s.stop_flow()
        if s.httpd:
            s.httpd.shutdown(); s.httpd.server_close(); s.httpd = None
        s.log("服務已停止")

    def urls(s):
        port = int(s.store.settings.get("port", 8080))
        return [f"http://{ip}:{port}/" for ip in local_ips()]

    def settings_url(s, section="settings"):
        return f"http://127.0.0.1:{int(s.store.settings.get('port', 8080))}/#{section}=1"

def merge_snmp(project, scanned):
    """把掃描結果的 SNMP 對應（host / ifIndex）套到現有的圖上，不更動版面。回傳 (對到的設備數, 對到的埠數)。"""
    nd = npt = 0
    for sd in scanned.get("devices", []):
        if not sd.get("snmp"): continue
        host = sd["snmp"]["host"]; hip = host.split(":")[0]
        cand = [d for d in project.get("devices", []) if (d.get("ip") and d["ip"] in (sd.get("ip"), hip)) or (d.get("name", "").lower() == sd.get("name", "").lower())]
        if not cand: continue
        d = cand[0]; d["snmp"] = {"host": host}; nd += 1
        by = {}
        for p in sd["ports"]:
            for k in {p["label"], *re.findall(r"\S+", p.get("note", ""))[:1]}: by.setdefault(str(k).lower(), p.get("ifIndex"))
        for p in d.get("ports", []):
            ix = by.get(str(p.get("label", "")).lower())
            if ix is not None and p.get("side") != 1: p["ifIndex"] = ix; npt += 1
    return nd, npt

def main():
    import argparse
    ap = argparse.ArgumentParser(description="netmap 監控服務（無視窗模式）")
    ap.add_argument("--port", type=int); ap.add_argument("--interval", type=int); ap.add_argument("--data")
    ap.add_argument("--flow", action="store_true", help="同時接收 NetFlow／IPFIX（UDP 2055）與 sFlow（UDP 6343）")
    ap.add_argument("--set-password", action="store_true", help="設定管理密碼（其他電腦要登入才能編輯、改設定）後結束")
    ap.add_argument("--view-link", action="store_true", help="產生（或顯示）只能檢視的連結後結束")
    a = ap.parse_args()
    st = Store(a.data)
    if a.set_password:
        import getpass
        pw = getpass.getpass("新的管理密碼（留空＝取消密碼）：")
        if pw and len(pw) < 6: print("至少 6 個字"); return
        if pw and getpass.getpass("再輸入一次：") != pw: print("兩次不一樣"); return
        st.settings["admin_hash"] = hash_pw(pw) if pw else ""; st.save_settings(); print("已設定管理密碼" if pw else "已取消管理密碼"); return
    if a.view_link:
        if not st.settings.get("view_token"): st.settings["view_token"] = secrets.token_urlsafe(18); st.save_settings()
        port = int(a.port or st.settings.get("port", 8080))
        for ip in local_ips(): print(f"http://{ip}:{port}/?t={st.settings['view_token']}")
        return
    if a.flow: st.settings["flow_enabled"] = True
    if a.port: st.settings["port"] = a.port
    if a.interval: st.settings["interval"] = a.interval
    sv = Service(st); sv.start()
    print("網頁：", ", ".join(sv.urls()))
    try:
        while True: time.sleep(3600)
    except KeyboardInterrupt: sv.stop()

if __name__ == "__main__":
    main()
